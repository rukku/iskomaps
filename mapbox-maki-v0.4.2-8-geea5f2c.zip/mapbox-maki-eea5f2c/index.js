module.exports.dirname = __dirname;
